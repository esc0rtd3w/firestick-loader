#!/sbin/sh
###########################################
# --------------------------------------- #
# |         Aroma File Manager          | #
# |       version 1.80 - Calung         | #
# | Installer for supporting recoveries | #
# --------------------------------------- #
###########################################
# carliv@xda

if [ ! -e "/sdcard/clockworkmod/.aromafm" ]
then
  mkdir -p /sdcard/clockworkmod/.aromafm
fi
