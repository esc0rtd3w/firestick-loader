#!/bin/bash

cd $(dirname $0)

[[ $(uname -s) = "Darwin" ]] && INJECT=mediatek_inject.osx || INJECT=mediatek_inject.linux

if [ ! -f 2ndinit -o ! -f 2ndinitstub ]; then
	echo "2ndinit and/or 2ndinitstub is missing."
	echo "Did you extract all the zip files?"
	exit -1
fi

./handshake.py

echo "Injecting 2ndinit..."
./$INJECT firetv2 $(cat comport.txt) 2ndinit /system/bin/pppd u:object_r:system_file:s0

echo "Injecting 2ndinitstub..."
./$INJECT firetv2 $(cat comport.txt) 2ndinitstub /system/bin/ext4_resize -
