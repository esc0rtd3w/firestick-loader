#pragma once

void setup_ftrace(void);
void stop_ftrace(void);

extern const char *ftracedumpname;
