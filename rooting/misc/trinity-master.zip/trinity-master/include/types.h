#pragma once

#include <sys/types.h>

typedef enum { FALSE = 0, TRUE = 1 } bool;

typedef __uint32_t u32;
typedef __uint64_t u64;
