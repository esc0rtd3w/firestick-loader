#pragma once

int get_rand_pipe_fd(void);
