#pragma once

int get_rand_bpf_fd(void);
