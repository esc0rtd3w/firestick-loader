#pragma once

void tainted_postmortem(void);
