#pragma once

#include "syscall.h"

void handle_success(struct syscallrecord *rec);
