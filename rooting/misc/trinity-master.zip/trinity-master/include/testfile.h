#pragma once

int get_rand_testfile_fd(void);
