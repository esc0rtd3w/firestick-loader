#ifndef _DEVS_H
#define _DEVS_H 1

void process_bdev_param(char *optarg);
void init_bdev_list(void);
void dump_bdev_list(void);

#endif	/* _DEVS_H */
