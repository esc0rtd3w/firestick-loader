#!/bin/sh
autoreconf --install