# amonet

This is an exploit chain for Fire 7 (2015) (5th gen / ford / KFFOWI). It contains a MediaTek bootrom exploit and a LittleKernel bootloader exploit.

It is also partially applicable to the Fire 7 (2017) (7th gen / austin / KFAUWI), but lacks display support.

For installation instructions, see https://forum.xda-developers.com/amazon-fire/development/unlock-fire-t3899860

## License

`brom-payload` includes code from Linux kernel, and is therefore licensed under GPLv2.

`lk-payload`, `modules` and `microloader` are licensed under MIT.

See LICENSE.MIT and LICENSE.GPL2 for more details.
