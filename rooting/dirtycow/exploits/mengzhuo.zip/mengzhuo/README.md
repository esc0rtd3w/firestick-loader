# dirty-cow-golang
Dirty Cow implement in Go
![POC](https://raw.github.com/mengzhuo/dirty-cow-golang/master/poc_arm.jpg)