#if !__linux__
#error DirtyCow is only available for Linux and Android
#endif
