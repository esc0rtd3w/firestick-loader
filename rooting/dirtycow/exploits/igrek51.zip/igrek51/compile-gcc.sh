gcc -pthread src/dirtycowy.c -o bin/dirtycowy -Wall
