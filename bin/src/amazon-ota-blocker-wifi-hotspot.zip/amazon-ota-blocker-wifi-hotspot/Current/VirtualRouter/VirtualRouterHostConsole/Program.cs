﻿/*
* Virtual Router v1.0 - http://virtualrouter.codeplex.com
* Wifi Hot Spot for Windows 8, 7 and 2008 R2
* Copyright (c) 2013 Chris Pietschmann (http://pietschsoft.com)
* Licensed under the Microsoft Public License (Ms-PL)
* http://virtualrouter.codeplex.com/license
*/
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceModel;

namespace VirtualRouterHostConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Amazon OTA Blocker Virtual Host - esc0rtd3w / firepwn.com";

            string creditsCodeBase = "Based On Original Code From Virtual Router By Chris Pietschmann";

            //Console.WriteLine(AssemblyTitle + " " + AssemblyVersion);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(creditsCodeBase);
            Console.WriteLine("\n\n");

            if (args.Length > 0 && args[0] == "/?")
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                //Console.WriteLine("Usage: VirtualRouterHostConsole [SSID] [Passkey]");
                Console.WriteLine("Usage: BlockAmazonOTA [AmazonRegister] [Agressive]");
                Console.WriteLine("\n");
                Console.WriteLine("Example: BlockAmazonOTA 1 0");
                return;
            }


            var virtualRouterHost = new VirtualRouterHost.VirtualRouterHost();
            var serviceHost = new ServiceHost(virtualRouterHost);

            bool _isAmazonRegisterNeeded = true;
            bool _isAgressive = false;

            if (args.Length == 2)
            {
                var isAmazonRegisterNeeded = args[0];
                var isAgressive = args[1];

                if (isAmazonRegisterNeeded == "0")
                {
                    _isAmazonRegisterNeeded = false;
                }

                if (isAgressive == "0")
                {
                    _isAgressive = false;
                }

                //var strSSID = args[0];
                //var strPassKey = args[1];

                //virtualRouterHost.SetConnectionSettings(strSSID, 100);
                //virtualRouterHost.SetPassword(strPassKey);

                //Console.WriteLine("SSID: " + strSSID);
                //Console.WriteLine("Passkey: " + strPassKey);
                //Console.WriteLine();
            }


            // If no arguments entered, set defaults
            if (args.Length == 0)
            {
                _isAmazonRegisterNeeded = true;
                _isAgressive = false;
            }

            virtualRouterHost.SetConnectionSettings("Block Amazon OTA", 10);
            virtualRouterHost.SetPassword("aaaaaaaa");


            // Write Blacklisted Amazon Domains To HOSTS File
            using (StreamWriter w = File.AppendText(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "drivers/etc/hosts")))
            {
                w.WriteLine("\n# BEGIN Amazon OTA Blocker");
                w.WriteLine("127.0.0.1 amzdigital-a.akamaihd.net");
                w.WriteLine("127.0.0.1 amzdigitaldownloads.edgesuite.net");

                if (_isAmazonRegisterNeeded == false)
                {
                    w.WriteLine("127.0.0.1 softwareupdates.amazon.com");
                }

                w.WriteLine("127.0.0.1 updates.amazon.com");

                if (_isAgressive == true)
                {
                    w.WriteLine("\n# START Aggressive Blocking");
                    w.WriteLine("127.0.0.1 *.amazon.com");
                    w.WriteLine("127.0.0.1 *akamaihd.net");
                    w.WriteLine("127.0.0.1 *edgesuite.net");
                    w.WriteLine("# END Aggressive Blocking\n");
                }

                w.WriteLine("# END Amazon OTA Blocker\n");
            }


            var conns = virtualRouterHost.GetSharableConnections();
            var connToShare = conns.FirstOrDefault();
            if (!virtualRouterHost.Start(connToShare))
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(creditsCodeBase);
                Console.WriteLine("\n\n");
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("ERROR: Amazon OTA Blocker could not be started. Supported hardware may not have been found.");
                Console.WriteLine();
            }


            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(creditsCodeBase);
            Console.WriteLine("\n\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Starting Amazon OTA Blocker Service...");

            if (serviceHost.State != CommunicationState.Opened)
            {
                serviceHost.Open();
            }

            Console.WriteLine();

            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(creditsCodeBase);
            Console.WriteLine("\n\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Amazon OTA Blocker Service Running....");

            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(creditsCodeBase);
            Console.WriteLine("\n\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Please Connect To The Virtual WiFi Hotspot With FireTV/FireStick");
            Console.WriteLine("\n\n");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Network: Block Amazon OTA");
            Console.WriteLine("\n");
            Console.WriteLine("Password: aaaaaaaa");
            Console.WriteLine("\n\n\n\n");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("[Press Enter To Stop]");
            Console.WriteLine("\n");

            Console.ReadLine();

            serviceHost.Close();


            virtualRouterHost.Stop();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Amazon OTA Blocker Service Stopped.");
        }



        public static string AssemblyTitle
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                if (attributes.Length > 0)
                {
                    AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                    if (titleAttribute.Title != "")
                    {
                        return titleAttribute.Title;
                    }
                }
                return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
            }
        }

        public static string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        public static string AssemblyCopyright
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
            }
        }
    }
}
