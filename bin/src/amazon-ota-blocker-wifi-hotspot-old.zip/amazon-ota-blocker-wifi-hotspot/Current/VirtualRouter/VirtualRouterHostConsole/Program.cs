﻿/*
* Virtual Router v1.0 - http://virtualrouter.codeplex.com
* Wifi Hot Spot for Windows 8, 7 and 2008 R2
* Copyright (c) 2013 Chris Pietschmann (http://pietschsoft.com)
* Licensed under the Microsoft Public License (Ms-PL)
* http://virtualrouter.codeplex.com/license
*/
using System;
using System.Linq;
using System.Reflection;
using System.ServiceModel;

namespace VirtualRouterHostConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Amazon OTA Blocker Virtual Host - esc0rtd3w / firepwn.com";

            //Console.WriteLine(AssemblyTitle + " " + AssemblyVersion);
            Console.WriteLine("Based On Original Code Base From Virtual Router By Chris Pietschmann");
            Console.WriteLine("\n\n");

            if (args.Length > 0 && args[0] == "/?")
            {
                Console.WriteLine("Usage: VirtualRouterHostConsole [SSID] [Passkey]");
                return;
            }


            var virtualRouterHost = new VirtualRouterHost.VirtualRouterHost();
            var serviceHost = new ServiceHost(virtualRouterHost);

            if(args.Length == 2)
            {
                var strSSID = args[0];
                var strPassKey = args[1];

                virtualRouterHost.SetConnectionSettings(strSSID, 100);
                virtualRouterHost.SetPassword(strPassKey);

                Console.WriteLine("SSID: " + strSSID);
                Console.WriteLine("Passkey: " + strPassKey);
                Console.WriteLine();
            }           


            var conns = virtualRouterHost.GetSharableConnections();
            var connToShare = conns.FirstOrDefault();
            if (!virtualRouterHost.Start(connToShare))
            {
                Console.Clear();
                Console.WriteLine("Based On Original Code Base From Virtual Router By Chris Pietschmann");
                Console.WriteLine("\n\n");
                Console.WriteLine("ERROR: Amazon OTA Blocker could not be started. Supported hardware may not have been found.");
                Console.WriteLine();
            }


            Console.Clear();
            Console.WriteLine("Based On Original Code Base From Virtual Router By Chris Pietschmann");
            Console.WriteLine("\n\n");
            Console.WriteLine("Starting Amazon OTA Blocker Service...");

            if (serviceHost.State != CommunicationState.Opened)
            {
                serviceHost.Open();
            }

            Console.WriteLine();

            Console.Clear();
            Console.WriteLine("Based On Original Code Base From Virtual Router By Chris Pietschmann");
            Console.WriteLine("\n\n");
            Console.WriteLine("Amazon OTA Blocker Service Running....");

            Console.Clear();
            Console.WriteLine("Based On Original Code Base From Virtual Router By Chris Pietschmann");
            Console.WriteLine("\n\n");
            Console.WriteLine("Please Connect To: Block Amazon OTA");
            Console.WriteLine("\n\n");
            Console.WriteLine("[Press Enter To Stop]");
            Console.WriteLine("\n");

            Console.ReadLine();

            serviceHost.Close();


            virtualRouterHost.Stop();

            Console.WriteLine("Amazon OTA Blocker Service Stopped.");
        }



        public static string AssemblyTitle
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                if (attributes.Length > 0)
                {
                    AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                    if (titleAttribute.Title != "")
                    {
                        return titleAttribute.Title;
                    }
                }
                return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
            }
        }

        public static string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        public static string AssemblyCopyright
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
            }
        }
    }
}
