Dex Manager v1.1 By Jasi2169/Team URET
==================================================
Changelog :-
v1.1 (Released On 12/August/2015)
- Updated Baksmali/Smali To v2.0.6.
- Now All Compile,Decompile And Delete Error Are Redirected To Errorbox.
- Add Option To Copy Error From Error Box To Clipboard.
- Now Dex Manager Reads baksmali.jar and smali.jar From Binaries Folder So When New Update Of Baksmali/Smali Comes You Can Copy Replace The Baksmali/Smali With Latest One.
- Change App Icon.
- Change App Skin Same As iTunes.
- Rework UI And Incresed UI Size.
- Code Refactor.
- Minor Optimization.
==================================================
Requirements :-
WinRAR Or 7Zip To Drag "Classes.dex" From Apk Or Jar File
JRE 1.7 or Above
Microsoft .Net Framework v4.0 And Above
==================================================
License :-
Free
==================================================
Info :-
It Is Intended To Make Your Work Easy.
It Could Be Used  For GOOD Purposes.
It Is NOT Intended For Piracy And Other Non-Legal Uses.
==================================================
Thanks To JesusFreke For His Baksmali/Smali.

Good Luck :)